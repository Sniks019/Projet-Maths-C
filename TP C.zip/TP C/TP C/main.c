#include <stdio.h>
#include <stdlib.h>
#include "Include/aff.h"
#include "Include/exos.h"

int main()
{
    menu();

    int choix;
    scanf("%d\n", &choix);
	int ptsT;
	ptsT = 0;
	

    while(choix != 0)
    {
        switch(choix)
        {
        case 1: add(); break;
        case 2: sous(); break;
        case 3: mult(); break;
        case 4: tabmult(); break;
        case 5: divis(); break;
        default: printf("Erreur: choix doit etre comprit entre 0 et 5.\n");
        }
		ptsT += 1;
        system("cls");
        menu();
        scanf("%d\n", &choix);
    }

    printf("Merci de votre visite\n");
    return 0;
}

/** 
	*gcc.exe main.c Source/*.c -I Include -o test_vers3 
	*Compilation depuis le dossier ou se trouvent les fichiers
*/