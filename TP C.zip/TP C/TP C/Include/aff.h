/**
    *Affiche le menu principal.
*/

void menu();