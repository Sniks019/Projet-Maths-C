#include <stdio.h>
#include <stdlib.h>

void menu()
    {
        printf(" +------------------------------------+\n");
        printf(" | 1 : Addition                       |\n");
        printf(" | 2 : Soustraction                   |\n");
        printf(" | 3 : Multiplication                 |\n");
        printf(" | 4 : Tables des multiplications     |\n");
        printf(" | 5 : Divisions                      |\n");
        printf(" | 0 : Sortir du jeu                  |\n");
        printf(" +------------------------------------+\n");
        printf(" Quel est votre choix ? ");
    }